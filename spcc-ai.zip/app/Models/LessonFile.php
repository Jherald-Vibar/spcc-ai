<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Number;

class LessonFile extends Model
{
    protected $fillable = ['lesson_id', 'name', 'path', 'extension', 'bytes'];

    public function lesson(): BelongsTo
    {
        return $this->belongsTo(Lesson::class);
    }

    /** $file['type'] in the materials list, e.g. PDF. */
    public function getTypeAttribute(): string
    {
        return strtoupper($this->extension);
    }

    /** $file['size'] in the materials list, e.g. 1.2 MB. */
    public function getSizeAttribute(): string
    {
        return Number::fileSize((int) $this->bytes, 1);
    }
}
