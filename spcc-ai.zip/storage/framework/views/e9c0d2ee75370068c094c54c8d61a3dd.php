<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($roleLabel); ?> | SPCC AI Learning Assistant</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="min-h-full bg-slate-100 font-sans text-slate-800 antialiased">
    
    <header class="flex items-center justify-between bg-blue-950 px-6 py-3 text-white">
        <div class="flex items-center gap-3">
            <?php if (isset($component)) { $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand-logo','data' => ['size' => 'size-9']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'size-9']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $attributes = $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $component = $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
            <span class="font-semibold">SPCC AI <span class="font-normal text-blue-200">Learning Assistant</span></span>
        </div>

        <div class="flex items-center gap-4 text-sm">
            <span class="hidden sm:inline"><?php echo e(auth()->user()->name); ?></span>
            <span class="rounded-full bg-white/10 px-2.5 py-0.5 text-xs font-medium"><?php echo e($roleLabel); ?></span>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="rounded-md bg-white/10 px-3 py-1.5 font-medium hover:bg-white/20">Logout</button>
            </form>
        </div>
    </header>

    <main class="mx-auto max-w-3xl px-6 py-16 text-center">
        <h1 class="text-2xl font-bold text-slate-900">Welcome, <?php echo e(auth()->user()->name); ?>!</h1>
        <p class="mt-2 text-slate-600">You are signed in as <strong><?php echo e($roleLabel); ?></strong>. The <?php echo e(strtolower($roleLabel)); ?> dashboard is built in the next step.</p>
    </main>
</body>
</html>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/dashboard.blade.php ENDPATH**/ ?>