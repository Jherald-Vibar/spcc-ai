<?php if (isset($component)) { $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.auth','data' => ['title' => 'Verify your email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Verify your email']); ?>
    <h1 class="text-center text-lg font-semibold text-slate-900">Enter the 6-digit code</h1>
    <p class="mt-1 text-center text-sm text-slate-500">
        We sent the code to<br>
        <span class="break-all font-semibold text-slate-800"><?php echo e($email); ?></span>
    </p>

    <form method="POST" action="<?php echo e(route('otp.verify')); ?>" id="otp-form" class="mt-6 space-y-5" novalidate>
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginal671d08622d65f2db8ae8bd59009ea50d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.alerts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $attributes = $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $component = $__componentOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>

        <input type="hidden" name="code" id="otp-code">

        <div id="otp-boxes" class="flex justify-center gap-2 sm:gap-3" role="group" aria-label="6-digit verification code">
            <?php for($i = 0; $i < 6; $i++): ?>
                <input type="text" inputmode="numeric" pattern="[0-9]*" maxlength="1"
                       autocomplete="<?php echo e($i === 0 ? 'one-time-code' : 'off'); ?>" aria-label="Digit <?php echo e($i + 1); ?>"
                       class="size-11 rounded-lg border border-slate-300 bg-white text-center text-xl font-semibold text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 sm:size-12">
            <?php endfor; ?>
        </div>

        <button type="submit"
                class="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
            Verify
        </button>
    </form>

    <form method="POST" action="<?php echo e(route('otp.resend')); ?>" class="mt-5 text-center">
        <?php echo csrf_field(); ?>
        <button type="submit" id="resend-btn" data-cooldown="<?php echo e($cooldown); ?>"
                class="text-sm font-medium text-blue-700 hover:text-blue-800 hover:underline disabled:cursor-not-allowed disabled:text-slate-400 disabled:no-underline">
            Resend code <span id="resend-timer"></span>
        </button>
    </form>

    <p class="mt-4 text-center text-sm text-slate-500">
        Wrong email?
        <a href="<?php echo e(route('register')); ?>" class="font-medium text-blue-700 hover:text-blue-800 hover:underline">Start over</a>
    </p>

    <?php $__env->startPush('scripts'); ?>
        <script>
            (function () {
                // --- six digit boxes -------------------------------------------------
                var boxes = Array.prototype.slice.call(document.querySelectorAll('#otp-boxes input'));
                var hidden = document.getElementById('otp-code');

                function sync() {
                    hidden.value = boxes.map(function (b) { return b.value; }).join('');
                }

                boxes.forEach(function (box, i) {
                    box.addEventListener('input', function () {
                        box.value = box.value.replace(/\D/g, '').slice(-1);
                        sync();
                        if (box.value && i < boxes.length - 1) boxes[i + 1].focus();
                    });

                    box.addEventListener('keydown', function (e) {
                        if (e.key === 'Backspace' && !box.value && i > 0) {
                            boxes[i - 1].focus();
                            boxes[i - 1].value = '';
                            sync();
                        } else if (e.key === 'ArrowLeft' && i > 0) {
                            boxes[i - 1].focus();
                        } else if (e.key === 'ArrowRight' && i < boxes.length - 1) {
                            boxes[i + 1].focus();
                        }
                    });

                    box.addEventListener('focus', function () { box.select(); });

                    box.addEventListener('paste', function (e) {
                        e.preventDefault();
                        var digits = ((e.clipboardData || window.clipboardData).getData('text') || '').replace(/\D/g, '').slice(0, boxes.length);
                        digits.split('').forEach(function (d, k) { boxes[k].value = d; });
                        sync();
                        boxes[Math.min(digits.length, boxes.length - 1)].focus();
                    });
                });

                document.getElementById('otp-form').addEventListener('submit', sync);
                boxes[0].focus();

                // --- resend countdown ------------------------------------------------
                var btn = document.getElementById('resend-btn');
                var label = document.getElementById('resend-timer');
                var left = parseInt(btn.dataset.cooldown, 10) || 0;

                function render() {
                    if (left > 0) {
                        var m = String(Math.floor(left / 60)).padStart(2, '0');
                        var s = String(left % 60).padStart(2, '0');
                        label.textContent = '(' + m + ':' + s + ')';
                        btn.disabled = true;
                    } else {
                        label.textContent = '';
                        btn.disabled = false;
                    }
                }

                render();
                if (left > 0) {
                    var timer = setInterval(function () {
                        left--;
                        render();
                        if (left <= 0) clearInterval(timer);
                    }, 1000);
                }
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $attributes = $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $component = $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/auth/otp.blade.php ENDPATH**/ ?>