<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $map = [
        'completed'   => ['Completed',   'bg-green-100 text-green-700 ring-green-200'],
        'in_progress' => ['In Progress', 'bg-amber-100 text-amber-700 ring-amber-200'],
        'upcoming'    => ['Upcoming',    'bg-slate-100 text-slate-600 ring-slate-200'],
    ];
    [$label, $classes] = $map[$status] ?? $map['upcoming'];
?>
<span <?php echo e($attributes->class(['inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset', $classes])); ?>><?php echo e($label); ?></span>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/components/student/status-badge.blade.php ENDPATH**/ ?>