<?php if (isset($component)) { $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.teacher','data' => ['title' => 'Profile','active' => 'profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.teacher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Profile','active' => 'profile']); ?>
    <?php ($user = auth()->user()); ?>
    <div class="max-w-2xl rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <div class="flex items-center gap-4">
            <span class="grid size-16 place-items-center rounded-full bg-blue-700 text-xl font-bold text-white"><?php echo e(mb_strtoupper(mb_substr($user->name, 0, 1))); ?></span>
            <div>
                <h2 class="text-lg font-bold text-slate-900"><?php echo e($user->name); ?></h2>
                <p class="text-sm text-slate-500">Teacher</p>
            </div>
        </div>
        <dl class="mt-6 divide-y divide-slate-100 text-sm">
            <div class="flex justify-between gap-4 py-3"><dt class="text-slate-500">Full name</dt><dd class="font-medium text-slate-900"><?php echo e($user->name); ?></dd></div>
            <div class="flex justify-between gap-4 py-3"><dt class="text-slate-500">SPCC email</dt><dd class="font-medium text-slate-900"><?php echo e($user->email); ?></dd></div>
            <div class="flex justify-between gap-4 py-3"><dt class="text-slate-500">Role</dt><dd class="font-medium text-slate-900">Teacher</dd></div>
        </dl>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $attributes = $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $component = $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/teacher/profile.blade.php ENDPATH**/ ?>