<?php
    $tabs = [
        'overview'  => 'Overview',
        'video'     => 'AI Video',
        'chat'      => 'AI Chat',
        'reviewer'  => 'Reviewer',
        'materials' => 'Materials',
        'forum'     => 'Forum',
    ];

    $tools = [
        ['chat',      'AI Chat',   'Ask lesson-related questions', 'chat',            'bg-orange-100 text-orange-600'],
        ['reviewer',  'Reviewer',  'Practice questions (MCQ, ID, etc.)', 'clipboard-check', 'bg-green-100 text-green-600'],
        ['materials', 'Materials', 'View / Download files',        'folder',          'bg-sky-100 text-sky-600'],
        ['forum',     'Forum',     'Discuss with classmates',      'users',           'bg-violet-100 text-violet-600'],
    ];
?>

<?php if (isset($component)) { $__componentOriginalbc2d976ddc1cb07339bc438da48a7318 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.student','data' => ['title' => 'Week '.$lesson['week'].' – '.$lesson['title'],'active' => 'lessons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Week '.$lesson['week'].' – '.$lesson['title']),'active' => 'lessons']); ?>
    
    <nav class="mb-4 flex flex-wrap items-center gap-1.5 text-sm text-slate-500" aria-label="Breadcrumb">
        <a href="<?php echo e(route('student.lessons')); ?>" class="hover:text-blue-700 hover:underline">My Lessons</a>
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <a href="<?php echo e(route('student.lessons', ['year' => $subject['year'], 'subject' => $subject['code']])); ?>" class="hover:text-blue-700 hover:underline"><?php echo e($subject['code']); ?></a>
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <span class="font-medium text-slate-700">Week <?php echo e($lesson['week']); ?></span>
    </nav>

    <div class="grid gap-6 xl:grid-cols-[1fr_18rem]">

        
        <section class="min-w-0 rounded-xl bg-white shadow-sm ring-1 ring-slate-200">
            <div class="flex flex-wrap items-center gap-3 px-6 pt-5">
                <?php if (isset($component)) { $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand-logo','data' => ['size' => 'size-9']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'size-9']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $attributes = $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $component = $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
                <div class="min-w-0 flex-1">
                    <h2 class="truncate text-lg font-bold text-slate-900">Week <?php echo e($lesson['week']); ?> &ndash; <?php echo e($lesson['title']); ?></h2>
                    <p class="truncate text-xs text-slate-500"><?php echo e($subject['name']); ?></p>
                </div>
                <?php if (isset($component)) { $__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.status-badge','data' => ['status' => $lesson['status']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lesson['status'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685)): ?>
<?php $attributes = $__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685; ?>
<?php unset($__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685)): ?>
<?php $component = $__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685; ?>
<?php unset($__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685); ?>
<?php endif; ?>
            </div>

            
            <div class="mt-4 overflow-x-auto border-b border-slate-200 px-6">
                <div class="flex min-w-max gap-6" role="tablist">
                    <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" role="tab" data-tab="<?php echo e($key); ?>"
                                aria-selected="<?php echo e($tab === $key ? 'true' : 'false'); ?>"
                                class="-mb-px border-b-2 px-1 pb-3 text-sm font-medium transition
                                       <?php echo e($tab === $key ? 'border-blue-700 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-800'); ?>">
                            <?php echo e($label); ?>

                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="p-6">
                <div data-panel="overview" class="<?php echo e($tab === 'overview' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.overview', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div data-panel="video"    class="<?php echo e($tab === 'video' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.video', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div data-panel="chat"     class="<?php echo e($tab === 'chat' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.chat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div data-panel="reviewer" class="<?php echo e($tab === 'reviewer' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.reviewer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div data-panel="materials" class="<?php echo e($tab === 'materials' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.materials', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div data-panel="forum"    class="<?php echo e($tab === 'forum' ? '' : 'hidden'); ?>"><?php echo $__env->make('student.lessons.partials.forum', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
            </div>
        </section>

        
        <aside class="h-fit rounded-xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
            <h3 class="font-semibold text-slate-900">Quick Tools</h3>
            <div class="mt-4 space-y-2">
                <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$target, $name, $hint, $icon, $tone]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-tab-trigger="<?php echo e($target); ?>"
                            class="flex w-full items-center gap-3 rounded-lg border border-slate-200 p-3 text-left transition hover:border-blue-300 hover:bg-blue-50/50">
                        <span class="grid size-10 shrink-0 place-items-center rounded-lg <?php echo e($tone); ?>">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <span class="min-w-0">
                            <span class="block text-sm font-semibold text-slate-900"><?php echo e($name); ?></span>
                            <span class="block truncate text-xs text-slate-500"><?php echo e($hint); ?></span>
                        </span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </aside>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            (function () {
                var tabs = document.querySelectorAll('[data-tab]');
                var panels = document.querySelectorAll('[data-panel]');
                var on = ['border-blue-700', 'text-blue-700'];
                var off = ['border-transparent', 'text-slate-500', 'hover:text-slate-800'];

                function show(key) {
                    tabs.forEach(function (t) {
                        var active = t.dataset.tab === key;
                        t.setAttribute('aria-selected', active ? 'true' : 'false');
                        on.forEach(function (c) { t.classList.toggle(c, active); });
                        off.forEach(function (c) { t.classList.toggle(c, !active); });
                    });
                    panels.forEach(function (p) { p.classList.toggle('hidden', p.dataset.panel !== key); });
                    history.replaceState(null, '', '?tab=' + key);
                }

                tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.dataset.tab); }); });
                document.querySelectorAll('[data-tab-trigger]').forEach(function (b) {
                    b.addEventListener('click', function () {
                        show(b.dataset.tabTrigger);
                        document.querySelector('[data-tab="' + b.dataset.tabTrigger + '"]').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    });
                });
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $attributes = $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $component = $__componentOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/student/lessons/show.blade.php ENDPATH**/ ?>