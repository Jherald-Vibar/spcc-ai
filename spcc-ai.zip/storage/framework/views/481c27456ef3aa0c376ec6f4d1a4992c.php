
<form id="reviewer-form" class="space-y-5">
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <fieldset class="rounded-lg border border-slate-200 p-4" data-answer="<?php echo e($q['answer']); ?>">
            <legend class="px-1 text-sm font-semibold text-slate-900"><?php echo e($i + 1); ?>. <?php echo e($q['q']); ?></legend>
            <div class="mt-2 space-y-1.5">
                <?php $__currentLoopData = $q['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="flex cursor-pointer items-center gap-3 rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-50" data-option="<?php echo e($j); ?>">
                        <input type="radio" name="q<?php echo e($i); ?>" value="<?php echo e($j); ?>" class="size-4 border-slate-300 text-blue-700 focus:ring-blue-600">
                        <?php echo e($option); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </fieldset>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="flex items-center gap-4">
        <button type="submit" class="rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800">Check answers</button>
        <p id="reviewer-score" class="text-sm font-medium text-slate-700"></p>
    </div>
</form>

<?php $__env->startPush('scripts'); ?>
    <script>
        (function () {
            var form = document.getElementById('reviewer-form');
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                var sets = form.querySelectorAll('fieldset');
                var correct = 0;

                sets.forEach(function (set) {
                    var answer = set.dataset.answer;
                    var picked = set.querySelector('input:checked');
                    set.querySelectorAll('label').forEach(function (l) {
                        l.classList.remove('bg-green-50', 'text-green-700', 'bg-red-50', 'text-red-700');
                    });
                    set.querySelector('[data-option="' + answer + '"]').classList.add('bg-green-50', 'text-green-700');
                    if (picked && picked.value === answer) {
                        correct++;
                    } else if (picked) {
                        picked.closest('label').classList.add('bg-red-50', 'text-red-700');
                    }
                });

                document.getElementById('reviewer-score').textContent = 'Score: ' + correct + ' / ' + sets.length;
            });
        })();
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/student/lessons/partials/reviewer.blade.php ENDPATH**/ ?>