<?php if (isset($component)) { $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.teacher','data' => ['title' => 'Settings','active' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.teacher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Settings','active' => 'settings']); ?>
    <div class="max-w-2xl rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <h2 class="font-semibold text-slate-900">Account settings</h2>
        <p class="mt-2 text-sm text-slate-500">Password change and notification preferences will be available here.</p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $attributes = $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $component = $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/teacher/settings.blade.php ENDPATH**/ ?>