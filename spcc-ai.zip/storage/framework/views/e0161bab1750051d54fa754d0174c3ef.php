<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'Dashboard', 'active' => 'dashboard']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'Dashboard', 'active' => 'dashboard']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $nav = [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'home',       'route' => 'admin.dashboard'],
        ['key' => 'users',     'label' => 'Users',     'icon' => 'users',      'route' => 'admin.users'],
        ['key' => 'subjects',  'label' => 'Subjects',  'icon' => 'academic-cap', 'route' => 'admin.subjects'],
        ['key' => 'lessons',   'label' => 'Lessons',   'icon' => 'book-open',  'route' => 'admin.lessons'],
        ['key' => 'reports',   'label' => 'Reports',   'icon' => 'chart-bar',  'route' => 'admin.reports'],
        ['key' => 'settings',  'label' => 'Settings',  'icon' => 'cog',        'route' => 'admin.settings'],
    ];
    $menu = [
        ['label' => 'Settings', 'route' => 'admin.settings'],
    ];
?>
<?php if (isset($component)) { $__componentOriginalbd26f90b0e8ad6cc54a49c99a73eac08 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd26f90b0e8ad6cc54a49c99a73eac08 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.panel','data' => ['title' => $title,'active' => $active,'nav' => $nav,'menu' => $menu,'roleLabel' => 'Administrator']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($active),'nav' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nav),'menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu),'role-label' => 'Administrator']); ?>
    <?php echo e($slot); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd26f90b0e8ad6cc54a49c99a73eac08)): ?>
<?php $attributes = $__attributesOriginalbd26f90b0e8ad6cc54a49c99a73eac08; ?>
<?php unset($__attributesOriginalbd26f90b0e8ad6cc54a49c99a73eac08); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd26f90b0e8ad6cc54a49c99a73eac08)): ?>
<?php $component = $__componentOriginalbd26f90b0e8ad6cc54a49c99a73eac08; ?>
<?php unset($__componentOriginalbd26f90b0e8ad6cc54a49c99a73eac08); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/components/layouts/admin.blade.php ENDPATH**/ ?>