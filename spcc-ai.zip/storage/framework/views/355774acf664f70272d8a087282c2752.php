<?php if (isset($component)) { $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.auth','data' => ['title' => 'Sign in']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sign in']); ?>
    
    <?php ($showPassword = $errors->any() || old('email') || $prefill); ?>

    <h1 class="text-center text-lg font-semibold text-slate-900">
        <?php echo e($prefill ? 'Welcome Back!' : 'Sign in with your SPCC account'); ?>

    </h1>
    <p class="mt-1 text-center text-sm text-slate-500">
        <?php echo e($prefill ? 'Your account is verified. Sign in with your SPCC account.' : 'Use your school email to continue.'); ?>

    </p>

    <form method="POST" action="<?php echo e(route('login.store')); ?>" id="login-form" class="mt-6 space-y-4" novalidate>
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginal671d08622d65f2db8ae8bd59009ea50d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.alerts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $attributes = $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $component = $__componentOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>

        <div>
            <?php if (isset($component)) { $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.input','data' => ['name' => 'email','type' => 'email','label' => 'SPCC email','icon' => 'envelope','value' => $prefill,'placeholder' => 'Surname_name@spcc.edu.ph','autocomplete' => 'username','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','type' => 'email','label' => 'SPCC email','icon' => 'envelope','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($prefill),'placeholder' => 'Surname_name@spcc.edu.ph','autocomplete' => 'username','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $attributes = $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $component = $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
            <p id="email-error" class="mt-1.5 hidden text-sm text-red-600"></p>
        </div>

        <div id="password-step" class="<?php echo e($showPassword ? '' : 'hidden'); ?> space-y-4">
            <?php if (isset($component)) { $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.input','data' => ['name' => 'password','type' => 'password','label' => 'Password','icon' => 'lock-closed','placeholder' => 'Enter your password','autocomplete' => 'current-password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','type' => 'password','label' => 'Password','icon' => 'lock-closed','placeholder' => 'Enter your password','autocomplete' => 'current-password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $attributes = $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $component = $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>

            <div class="flex items-center justify-between text-sm">
                <label class="inline-flex cursor-pointer items-center gap-2 text-slate-600">
                    <input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>
                           class="size-4 rounded border-slate-300 text-blue-700 focus:ring-blue-600">
                    Remember me
                </label>
                <a href="#" class="font-medium text-blue-700 hover:text-blue-800 hover:underline">Forgot password?</a>
            </div>
        </div>

        <button type="button" id="next-btn"
                class="<?php echo e($showPassword ? 'hidden' : ''); ?> w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
            Next
        </button>

        <button type="submit" id="signin-btn"
                class="<?php echo e($showPassword ? '' : 'hidden'); ?> w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
            Sign In
        </button>
    </form>

    <p class="mt-6 text-center text-sm text-slate-600">
        Don't have an account?
        <a href="<?php echo e(route('register')); ?>" class="font-semibold text-blue-700 hover:text-blue-800 hover:underline">Register</a>
    </p>

    <?php $__env->startPush('scripts'); ?>
        <script>
            (function () {
                var form = document.getElementById('login-form');
                var email = document.getElementById('email');
                var password = document.getElementById('password');
                var step = document.getElementById('password-step');
                var nextBtn = document.getElementById('next-btn');
                var signinBtn = document.getElementById('signin-btn');
                var error = document.getElementById('email-error');
                var spcc = /^[a-z0-9._-]+@spcc\.edu\.ph$/i;

                function goNext() {
                    if (!spcc.test(email.value.trim())) {
                        error.textContent = 'Only SPCC accounts are allowed. Use Surname_name@spcc.edu.ph.';
                        error.classList.remove('hidden');
                        email.focus();
                        return;
                    }
                    error.classList.add('hidden');
                    step.classList.remove('hidden');
                    nextBtn.classList.add('hidden');
                    signinBtn.classList.remove('hidden');
                    password.focus();
                }

                nextBtn.addEventListener('click', goNext);

                // Enter in the email box moves to the password step instead of submitting
                form.addEventListener('submit', function (e) {
                    if (step.classList.contains('hidden')) {
                        e.preventDefault();
                        goNext();
                    }
                });

                if (!step.classList.contains('hidden') && email.value) {
                    password.focus();
                }
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $attributes = $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $component = $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/auth/login.blade.php ENDPATH**/ ?>