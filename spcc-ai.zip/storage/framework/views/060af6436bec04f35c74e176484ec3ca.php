<?php if (isset($component)) { $__componentOriginalbc2d976ddc1cb07339bc438da48a7318 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.student','data' => ['title' => 'My Lessons','active' => 'lessons']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Lessons','active' => 'lessons']); ?>
    <div class="grid gap-6 lg:grid-cols-[22rem_1fr]">

        
        <section class="h-fit rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 class="flex items-center gap-2 font-semibold text-slate-900">
                <span class="grid size-6 place-items-center rounded-full bg-blue-700 text-xs font-bold text-white">1</span>
                Select Year and Subject
            </h2>

            <form method="GET" action="<?php echo e(route('student.lessons')); ?>" class="mt-5 space-y-4">
                <div>
                    <label for="year" class="mb-1.5 block text-sm font-medium text-slate-700">Year Level</label>
                    <select id="year" name="year" required
                            class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20">
                        <option value="">Select year level</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($selectedYear === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label for="subject" class="mb-1.5 block text-sm font-medium text-slate-700">Subject</label>
                    <select id="subject" name="subject" required
                            class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20">
                        <option value="">Select subject</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s['code']); ?>" data-year="<?php echo e($s['year']); ?>"
                                    <?php if($selectedSubject && $selectedSubject['code'] === $s['code']): echo 'selected'; endif; ?>>
                                <?php echo e($s['name']); ?> (<?php echo e($s['code']); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit"
                        class="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
                    Enter
                </button>
            </form>
        </section>

        
        <section class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 class="flex items-center gap-2 font-semibold text-slate-900">
                <span class="grid size-6 place-items-center rounded-full bg-blue-700 text-xs font-bold text-white">2</span>
                Available Lessons
            </h2>

            <?php if(! $selectedSubject): ?>
                <div class="mt-6 rounded-lg border border-dashed border-slate-300 px-6 py-12 text-center">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'book-open','class' => 'mx-auto size-10 text-slate-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-open','class' => 'mx-auto size-10 text-slate-300']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <p class="mt-3 text-sm text-slate-500">Choose your year level and subject, then press <strong>Enter</strong> to see the lessons.</p>
                </div>
            <?php else: ?>
                <p class="mt-3 text-sm font-medium text-slate-600">
                    <?php echo e($selectedSubject['code']); ?> &ndash; <?php echo e($years[$selectedSubject['year']]); ?>

                    <span class="font-normal text-slate-400">&middot; <?php echo e($selectedSubject['name']); ?></span>
                </p>

                <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($loop->first): ?> <ul class="mt-4 space-y-2"> <?php endif; ?>
                    <li>
                        <a href="<?php echo e(route('student.lessons.show', [$selectedSubject['code'], $lesson['week']])); ?>"
                           class="flex items-center gap-4 rounded-lg border border-slate-200 px-4 py-3 transition hover:border-blue-300 hover:bg-blue-50/60">
                            <span class="w-16 shrink-0 text-sm font-semibold text-blue-700">Week <?php echo e($lesson['week']); ?></span>
                            <span class="min-w-0 flex-1 truncate text-sm font-medium text-slate-800"><?php echo e($lesson['title']); ?></span>
                            <?php if (isset($component)) { $__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student.status-badge','data' => ['status' => $lesson['status'],'class' => 'hidden sm:inline-flex']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('student.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lesson['status']),'class' => 'hidden sm:inline-flex']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685)): ?>
<?php $attributes = $__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685; ?>
<?php unset($__attributesOriginal1b391b509b3aa7fef3a36ba4c77b7685); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685)): ?>
<?php $component = $__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685; ?>
<?php unset($__componentOriginal1b391b509b3aa7fef3a36ba4c77b7685); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','class' => 'size-4 shrink-0 text-slate-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-4 shrink-0 text-slate-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </a>
                    </li>
                    <?php if($loop->last): ?> </ul> <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="mt-6 rounded-lg border border-dashed border-slate-300 px-6 py-12 text-center text-sm text-slate-500">
                        No lessons have been published for this subject yet.
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            // show only the subjects that belong to the selected year level
            (function () {
                var year = document.getElementById('year');
                var subject = document.getElementById('subject');
                var options = Array.prototype.slice.call(subject.querySelectorAll('option[data-year]'));

                function filter() {
                    options.forEach(function (o) {
                        var match = !year.value || o.dataset.year === year.value;
                        o.hidden = !match;
                        o.disabled = !match;
                    });
                    if (subject.selectedOptions[0] && subject.selectedOptions[0].disabled) subject.value = '';
                }

                year.addEventListener('change', filter);
                filter();
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $attributes = $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $component = $__componentOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/student/lessons/index.blade.php ENDPATH**/ ?>