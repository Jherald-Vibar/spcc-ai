
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['size' => 'size-16']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['size' => 'size-16']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(file_exists(public_path('images/spcc-logo.png'))): ?>
    <img src="<?php echo e(asset('images/spcc-logo.png')); ?>" alt="SPCC logo" <?php echo e($attributes->class([$size, 'shrink-0 object-contain'])); ?>>
<?php else: ?>
    <svg viewBox="0 0 64 64" role="img" aria-label="SPCC logo" <?php echo e($attributes->class([$size, 'shrink-0'])); ?>>
        <circle cx="32" cy="32" r="30" fill="#1e3a8a" stroke="#f59e0b" stroke-width="3" />
        <circle cx="32" cy="32" r="24" fill="none" stroke="#f59e0b" stroke-opacity=".45" stroke-width="1" />
        <path d="M32 17 11 27.5 32 38l21-10.5L32 17Z" fill="#ffffff" />
        <path d="M20 33.5v8c0 3.2 5.4 6 12 6s12-2.8 12-6v-8L32 39.5l-12-6Z" fill="#fbbf24" />
        <path d="M53 28v10" stroke="#ffffff" stroke-width="2" stroke-linecap="round" />
    </svg>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/components/brand-logo.blade.php ENDPATH**/ ?>