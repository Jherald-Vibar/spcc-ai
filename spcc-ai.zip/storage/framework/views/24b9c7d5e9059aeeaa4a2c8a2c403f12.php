
<form class="mb-5" onsubmit="return false">
    <label for="forum-post" class="sr-only">Start a discussion</label>
    <textarea id="forum-post" rows="3" placeholder="Start a discussion or ask your classmates..."
              class="w-full rounded-lg border border-slate-300 px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"></textarea>
    <button type="submit" class="mt-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-800">Post</button>
</form>

<ul class="space-y-3">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="rounded-lg border border-slate-200 p-4">
            <div class="flex items-center gap-3">
                <span class="grid size-8 place-items-center rounded-full bg-violet-100 text-xs font-semibold text-violet-700"><?php echo e(mb_strtoupper(mb_substr($post['author'], 0, 1))); ?></span>
                <p class="text-sm font-semibold text-slate-900"><?php echo e($post['author']); ?></p>
                <p class="text-xs text-slate-400"><?php echo e($post['time']); ?></p>
            </div>
            <p class="mt-2 text-sm text-slate-700"><?php echo e($post['body']); ?></p>
            <p class="mt-2 text-xs font-medium text-blue-700"><?php echo e($post['replies']); ?> <?php echo e(\Illuminate\Support\Str::plural('reply', $post['replies'])); ?></p>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/student/lessons/partials/forum.blade.php ENDPATH**/ ?>