<?php
    $tabs = ['students' => 'Students', 'teachers' => 'Teachers', 'administrators' => 'Administrators'];
    $field = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20';
    $years = \App\Models\Subject::YEARS;
    $menuItem = 'block w-full rounded-md px-3 py-1.5 text-left text-sm text-slate-700 hover:bg-slate-50';
?>

<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'User Management','active' => 'users']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'User Management','active' => 'users']); ?>
    <section class="rounded-xl bg-white shadow-sm ring-1 ring-slate-200">
        <div class="flex flex-wrap items-center gap-3 px-6 pt-5">
            <h2 class="font-semibold text-slate-900">User Management</h2>
            <button type="button" id="add-user-btn"
                    class="ml-auto inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Add User
            </button>
        </div>

        
        <div class="mt-3 overflow-x-auto border-b border-slate-200 px-6">
            <div class="flex min-w-max gap-6">
                <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.users', ['role' => $key])); ?>"
                       <?php if($tab === $key): ?> aria-current="page" <?php endif; ?>
                       class="-mb-px border-b-2 px-1 pb-3 text-sm font-medium transition
                              <?php echo e($tab === $key ? 'border-blue-700 text-blue-700' : 'border-transparent text-slate-500 hover:text-slate-800'); ?>">
                        <?php echo e($label); ?> <span class="ml-1 rounded-full bg-slate-100 px-1.5 py-0.5 text-xs text-slate-500"><?php echo e($counts[$key]); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <form method="GET" action="<?php echo e(route('admin.users')); ?>" class="flex flex-wrap items-center gap-3 px-6 py-4">
            <input type="hidden" name="role" value="<?php echo e($tab); ?>">
            <div class="relative min-w-0 flex-1 sm:max-w-sm">
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'search','class' => 'pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'search','class' => 'pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                <input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Search users..." class="<?php echo e($field); ?> pl-9">
            </div>
            <select name="status" onchange="this.form.submit()" class="<?php echo e($field); ?> !w-auto" aria-label="Filter by status">
                <option value="">All statuses</option>
                <option value="active" <?php if($status === 'active'): echo 'selected'; endif; ?>>Active</option>
                <option value="inactive" <?php if($status === 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
            </select>
            <button type="submit" class="rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Filter</button>
        </form>

        
        <div class="overflow-x-auto">
            <table class="w-full min-w-[40rem] text-left text-sm">
                <thead class="border-y border-slate-200 bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                    <tr>
                        <th class="px-6 py-3 font-medium">Name</th>
                        <th class="px-6 py-3 font-medium">Email</th>
                        <th class="px-6 py-3 font-medium"><?php echo e($tab === 'students' ? 'Year' : 'Role'); ?></th>
                        <th class="px-6 py-3 font-medium">Status</th>
                        <th class="px-6 py-3 text-right font-medium">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($isSelf = $u->is(auth()->user())); ?>
                        <tr class="hover:bg-slate-50/60">
                            <td class="px-6 py-3 font-medium text-slate-900"><?php echo e($u->name); ?> <?php if($isSelf): ?><span class="ml-1 text-xs font-normal text-slate-400">(you)</span><?php endif; ?></td>
                            <td class="px-6 py-3 text-slate-600"><?php echo e($u->email); ?></td>
                            <td class="px-6 py-3 text-slate-600">
                                <?php if($u->role === 'student'): ?> <?php echo e($u->year_level ? ($years[$u->year_level] ?? '') : 'Not set'); ?>

                                <?php else: ?> <span class="capitalize"><?php echo e($u->role); ?></span> <?php endif; ?>
                            </td>
                            <td class="px-6 py-3"><?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['status' => $u->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($u->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?></td>
                            <td class="px-6 py-3 text-right">
                                <details class="relative inline-block text-left">
                                    <summary class="grid size-8 cursor-pointer list-none place-items-center rounded-md text-slate-500 hover:bg-slate-100 [&::-webkit-details-marker]:hidden" aria-label="User actions">
                                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'ellipsis-vertical','class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'ellipsis-vertical','class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                    </summary>
                                    <div class="absolute right-0 z-10 mt-1 w-44 rounded-lg bg-white p-1 shadow-lg ring-1 ring-slate-200">
                                        <button type="button" class="<?php echo e($menuItem); ?>" data-edit-user
                                                data-action="<?php echo e(route('admin.users.update', $u)); ?>"
                                                data-user="<?php echo e(json_encode(['name' => $u->name, 'email' => $u->email, 'role' => $u->role, 'year_level' => $u->year_level, 'self' => $isSelf])); ?>">Edit</button>

                                        <?php if (! ($isSelf)): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.toggle', $u)); ?>">
                                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="<?php echo e($menuItem); ?>"><?php echo e($u->isActive() ? 'Deactivate' : 'Activate'); ?></button>
                                            </form>
                                        <?php endif; ?>

                                        <form method="POST" action="<?php echo e(route('admin.users.reset', $u)); ?>" onsubmit="return confirm('Generate a new temporary password for <?php echo e(addslashes($u->name)); ?>?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="<?php echo e($menuItem); ?>">Reset password</button>
                                        </form>

                                        <?php if (! ($isSelf)): ?>
                                            <form method="POST" action="<?php echo e(route('admin.users.destroy', $u)); ?>" onsubmit="return confirm('Delete <?php echo e(addslashes($u->name)); ?>? This cannot be undone.')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="block w-full rounded-md px-3 py-1.5 text-left text-sm text-red-600 hover:bg-red-50">Delete</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </details>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-6 py-12 text-center text-slate-500">No users match your search.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($users->hasPages()): ?>
            <div class="border-t border-slate-100 px-6 py-4"><?php echo e($users->links()); ?></div>
        <?php endif; ?>
    </section>

    
    <dialog id="add-user" class="m-auto w-full max-w-md rounded-2xl p-0 shadow-2xl backdrop:bg-slate-900/50">
        <form method="POST" action="<?php echo e(route('admin.users.store')); ?>" class="p-6">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_form" value="create">
            <h3 class="text-lg font-semibold text-slate-900">Add User</h3>
            <p class="mt-1 text-sm text-slate-500">Only SPCC accounts are allowed. A temporary password is generated and shown once after saving.</p>

            <div class="mt-5 space-y-4">
                <div>
                    <label for="u-name" class="mb-1.5 block text-sm font-medium text-slate-700">Full name</label>
                    <input id="u-name" name="name" type="text" required value="<?php echo e(old('_form') === 'create' ? old('name') : ''); ?>" class="<?php echo e($field); ?>" placeholder="Surname, Given name">
                </div>
                <div>
                    <label for="u-email" class="mb-1.5 block text-sm font-medium text-slate-700">SPCC email</label>
                    <input id="u-email" name="email" type="email" required value="<?php echo e(old('_form') === 'create' ? old('email') : ''); ?>" class="<?php echo e($field); ?>" placeholder="Surname_name@spcc.edu.ph">
                </div>
                <div>
                    <label for="u-role" class="mb-1.5 block text-sm font-medium text-slate-700">Role</label>
                    <select id="u-role" name="role" class="<?php echo e($field); ?>" data-role-select>
                        <?php $__currentLoopData = ['student' => 'Student', 'teacher' => 'Teacher', 'admin' => 'Administrator']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if((old('_form') === 'create' ? old('role') : null) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div data-year-row>
                    <label for="u-year" class="mb-1.5 block text-sm font-medium text-slate-700">Year level</label>
                    <select id="u-year" name="year_level" class="<?php echo e($field); ?>">
                        <option value="">Not set</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if((int) (old('_form') === 'create' ? old('year_level') : 0) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mt-6 flex justify-end gap-3">
                <button type="button" data-close class="rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Cancel</button>
                <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800">Add User</button>
            </div>
        </form>
    </dialog>

    
    <dialog id="edit-user" class="m-auto w-full max-w-md rounded-2xl p-0 shadow-2xl backdrop:bg-slate-900/50">
        <form method="POST" action="#" id="edit-form" class="p-6">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <input type="hidden" name="_form" value="edit">
            <h3 class="text-lg font-semibold text-slate-900">Edit User</h3>

            <div class="mt-5 space-y-4">
                <div>
                    <label for="e-name" class="mb-1.5 block text-sm font-medium text-slate-700">Full name</label>
                    <input id="e-name" name="name" type="text" required class="<?php echo e($field); ?>">
                </div>
                <div>
                    <label for="e-email" class="mb-1.5 block text-sm font-medium text-slate-700">SPCC email</label>
                    <input id="e-email" name="email" type="email" required class="<?php echo e($field); ?>">
                </div>
                <div>
                    <label for="e-role" class="mb-1.5 block text-sm font-medium text-slate-700">Role</label>
                    <select id="e-role" name="role" class="<?php echo e($field); ?>" data-role-select>
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                        <option value="admin">Administrator</option>
                    </select>
                    <p id="e-role-note" class="mt-1 hidden text-xs text-slate-500">You cannot change your own role.</p>
                </div>
                <div data-year-row>
                    <label for="e-year" class="mb-1.5 block text-sm font-medium text-slate-700">Year level</label>
                    <select id="e-year" name="year_level" class="<?php echo e($field); ?>">
                        <option value="">Not set</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mt-6 flex justify-end gap-3">
                <button type="button" data-close class="rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Cancel</button>
                <button type="submit" class="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-800">Save changes</button>
            </div>
        </form>
    </dialog>

    <?php $__env->startPush('scripts'); ?>
        <script>
            (function () {
                var addDlg = document.getElementById('add-user');
                var editDlg = document.getElementById('edit-user');

                [addDlg, editDlg].forEach(function (dlg) {
                    dlg.querySelectorAll('[data-close]').forEach(function (b) { b.addEventListener('click', function () { dlg.close(); }); });
                    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); }); // click on backdrop

                    // year level only matters for students
                    var role = dlg.querySelector('[data-role-select]');
                    var row = dlg.querySelector('[data-year-row]');
                    function sync() { row.classList.toggle('hidden', role.value !== 'student'); }
                    role.addEventListener('change', sync);
                    dlg._sync = sync;
                    sync();
                });

                document.getElementById('add-user-btn').addEventListener('click', function () { addDlg.showModal(); });

                document.querySelectorAll('[data-edit-user]').forEach(function (btn) {
                    btn.addEventListener('click', function () {
                        var u = JSON.parse(btn.dataset.user);
                        document.getElementById('edit-form').action = btn.dataset.action;
                        document.getElementById('e-name').value = u.name;
                        document.getElementById('e-email').value = u.email;
                        document.getElementById('e-role').value = u.role;
                        document.getElementById('e-role').disabled = u.self;   // disabled fields are not submitted
                        document.getElementById('e-role-note').classList.toggle('hidden', !u.self);
                        document.getElementById('e-year').value = u.year_level || '';
                        editDlg._sync();
                        btn.closest('details').removeAttribute('open');
                        editDlg.showModal();
                    });
                });

                <?php if(old('_form') === 'create' && $errors->any()): ?> addDlg.showModal(); <?php endif; ?>
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/admin/users.blade.php ENDPATH**/ ?>