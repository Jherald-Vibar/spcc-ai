<?php if (isset($component)) { $__componentOriginalbc2d976ddc1cb07339bc438da48a7318 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.student','data' => ['title' => 'Settings','active' => 'settings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Settings','active' => 'settings']); ?>
    <div class="max-w-2xl rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <h2 class="font-semibold text-slate-900">Account settings</h2>
        <p class="mt-2 text-sm text-slate-500">Password change and notification preferences will be available here.</p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $attributes = $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $component = $__componentOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/student/settings.blade.php ENDPATH**/ ?>