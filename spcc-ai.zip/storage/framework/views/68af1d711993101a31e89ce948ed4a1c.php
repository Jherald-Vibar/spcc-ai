<?php if (isset($component)) { $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.teacher','data' => ['title' => 'Week '.$lesson->week.' – '.$lesson->title,'active' => 'subjects']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.teacher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Week '.$lesson->week.' – '.$lesson->title),'active' => 'subjects']); ?>
    <nav class="mb-4 flex flex-wrap items-center gap-1.5 text-sm text-slate-500" aria-label="Breadcrumb">
        <a href="<?php echo e(route('teacher.subjects')); ?>" class="hover:text-blue-700 hover:underline">My Subjects</a>
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <a href="<?php echo e(route('teacher.subjects', ['year' => $subject->year, 'subject' => $subject->code])); ?>" class="hover:text-blue-700 hover:underline"><?php echo e($subject->code); ?></a>
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-right','class' => 'size-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-right','class' => 'size-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
        <span class="font-medium text-slate-700">Week <?php echo e($lesson->week); ?></span>
    </nav>

    <section class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <div class="flex flex-wrap items-center gap-3">
            <h2 class="text-lg font-bold text-slate-900">Week <?php echo e($lesson->week); ?> &ndash; <?php echo e($lesson->title); ?></h2>
            <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['status' => $lesson->display_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lesson->display_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
            <div class="ml-auto flex gap-2">
                <a href="<?php echo e(route('teacher.lessons.edit', [$subject->code, $lesson->week])); ?>"
                   class="rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-800">Edit</a>
                <form method="POST" action="<?php echo e(route('teacher.lessons.publish', [$subject->code, $lesson->week])); ?>"><?php echo csrf_field(); ?>
                    <button type="submit" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"><?php echo e($lesson->isPublished() ? 'Move to draft' : 'Publish'); ?></button>
                </form>
            </div>
        </div>
        <p class="mt-1 text-sm text-slate-500"><?php echo e($subject->name); ?></p>

        <h3 class="mt-6 text-sm font-semibold text-slate-900">Description</h3>
        <p class="mt-1 whitespace-pre-line text-sm text-slate-600"><?php echo e($lesson->description ?: 'No description.'); ?></p>

        <?php if($lesson->ai_prompt): ?>
            <h3 class="mt-6 text-sm font-semibold text-slate-900">AI prompt</h3>
            <p class="mt-1 whitespace-pre-line rounded-lg bg-slate-50 p-3 text-sm text-slate-600 ring-1 ring-slate-200"><?php echo e($lesson->ai_prompt); ?></p>
        <?php endif; ?>

        <h3 class="mt-6 text-sm font-semibold text-slate-900">Materials</h3>
        <ul class="mt-2 divide-y divide-slate-100 rounded-lg ring-1 ring-slate-200">
            <?php $__empty_1 = true; $__currentLoopData = $lesson->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex items-center gap-4 px-4 py-3">
                    <span class="grid size-10 shrink-0 place-items-center rounded-lg bg-sky-100 text-xs font-bold text-sky-700"><?php echo e($file->type); ?></span>
                    <div class="min-w-0 flex-1">
                        <p class="truncate text-sm font-medium text-slate-900"><?php echo e($file->name); ?></p>
                        <p class="text-xs text-slate-500"><?php echo e($file->size); ?></p>
                        <?php if($file->processing_status === 'failed' && $file->processing_error): ?>
                            <p class="mt-0.5 text-xs text-red-600"><?php echo e($file->processing_error); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php
                        $aiChip = match ($file->processing_status) {
                            'ready'      => ['AI ready · '.$file->chunk_count.' chunks', 'bg-emerald-50 text-emerald-700 ring-emerald-200'],
                            'processing' => ['Processing…', 'bg-blue-50 text-blue-700 ring-blue-200'],
                            'failed'     => ['AI failed', 'bg-red-50 text-red-700 ring-red-200'],
                            default      => ['Queued', 'bg-slate-100 text-slate-600 ring-slate-200'],
                        };
                    ?>
                    <span class="hidden rounded-full px-2.5 py-1 text-xs font-medium ring-1 sm:inline-block <?php echo e($aiChip[1]); ?>"><?php echo e($aiChip[0]); ?></span>
                    <?php if(in_array($file->processing_status, ['failed', 'pending'], true)): ?>
                        <form method="POST" action="<?php echo e(route('teacher.files.reprocess', $file)); ?>"><?php echo csrf_field(); ?>
                            <button type="submit" class="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50">Retry AI</button>
                        </form>
                    <?php endif; ?>
                    <a href="<?php echo e(route('teacher.files.download', $file)); ?>" class="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50">Download</a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="px-4 py-6 text-center text-sm text-slate-500">No materials uploaded.</li>
            <?php endif; ?>
        </ul>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $attributes = $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $component = $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/teacher/lessons/show.blade.php ENDPATH**/ ?>