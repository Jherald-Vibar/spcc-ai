<?php if (isset($component)) { $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.teacher','data' => ['title' => 'My Subjects','active' => 'subjects']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.teacher'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'My Subjects','active' => 'subjects']); ?>
    <div class="grid gap-6 lg:grid-cols-[22rem_1fr]">

        
        <section class="h-fit rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h2 class="flex items-center gap-2 font-semibold text-slate-900">
                <span class="grid size-6 place-items-center rounded-full bg-blue-700 text-xs font-bold text-white">1</span>
                Select Year and Subject
            </h2>

            <form method="GET" action="<?php echo e(route('teacher.subjects')); ?>" class="mt-5 space-y-4">
                <div>
                    <label for="year" class="mb-1.5 block text-sm font-medium text-slate-700">Year Level</label>
                    <select id="year" name="year" required
                            class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20">
                        <option value="">Select year level</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($selectedYear === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label for="subject" class="mb-1.5 block text-sm font-medium text-slate-700">Subject</label>
                    <select id="subject" name="subject" required
                            class="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20">
                        <option value="">Select subject</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s['code']); ?>" data-year="<?php echo e($s['year']); ?>"
                                    <?php if($selectedSubject && $selectedSubject['code'] === $s['code']): echo 'selected'; endif; ?>>
                                <?php echo e($s['name']); ?> (<?php echo e($s['code']); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <button type="submit"
                        class="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
                    Enter
                </button>
            </form>
        </section>

        
        <section class="min-w-0 rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div class="flex flex-wrap items-center gap-3">
                <h2 class="flex items-center gap-2 font-semibold text-slate-900">
                    <span class="grid size-6 place-items-center rounded-full bg-blue-700 text-xs font-bold text-white">2</span>
                    Subject Dashboard
                </h2>
                <?php if($selectedSubject): ?>
                    <a href="<?php echo e(route('teacher.lessons.create', $selectedSubject['code'])); ?>"
                       class="ml-auto inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Create Lesson
                    </a>
                <?php endif; ?>
            </div>

            <?php if(! $selectedSubject): ?>
                <div class="mt-6 rounded-lg border border-dashed border-slate-300 px-6 py-12 text-center">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'book-open','class' => 'mx-auto size-10 text-slate-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-open','class' => 'mx-auto size-10 text-slate-300']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    <?php if($subjects->isEmpty()): ?>
                        <p class="mt-3 text-sm text-slate-500">No subject is assigned to you yet. Ask an administrator to assign one.</p>
                    <?php else: ?>
                    <p class="mt-3 text-sm text-slate-500">Choose a year level and subject, then press <strong>Enter</strong> to manage its lessons.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <p class="mt-3 text-sm font-medium text-slate-600">
                    <?php echo e($selectedSubject['code']); ?> &ndash; <?php echo e($years[$selectedSubject['year']]); ?>

                    <span class="font-normal text-slate-400">&middot; <?php echo e($selectedSubject['name']); ?></span>
                </p>

                
                <div class="mt-4 flex gap-6 border-b border-slate-200" role="tablist">
                    <button type="button" role="tab" data-tab="lessons" aria-selected="true"
                            class="-mb-px border-b-2 border-blue-700 px-1 pb-3 text-sm font-medium text-blue-700">Lessons</button>
                    <button type="button" role="tab" data-tab="analytics" aria-selected="false"
                            class="-mb-px border-b-2 border-transparent px-1 pb-3 text-sm font-medium text-slate-500 hover:text-slate-800">Analytics</button>
                </div>

                <div data-panel="lessons" class="mt-4">
                    <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($loop->first): ?> <ul class="space-y-2"> <?php endif; ?>
                        <li class="flex items-center gap-4 rounded-lg border border-slate-200 px-4 py-3">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'document','class' => 'size-5 shrink-0 text-blue-600']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'document','class' => 'size-5 shrink-0 text-blue-600']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            <span class="w-16 shrink-0 text-sm font-semibold text-slate-700">Week <?php echo e($lesson->week); ?></span>
                            <span class="min-w-0 flex-1 truncate text-sm text-slate-800"><?php echo e($lesson->title); ?></span>
                            <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['status' => $lesson->display_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($lesson->display_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>

                            <details class="relative">
                                <summary class="grid size-8 cursor-pointer list-none place-items-center rounded-md text-slate-500 hover:bg-slate-100 [&::-webkit-details-marker]:hidden" aria-label="Lesson actions">
                                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'ellipsis-vertical','class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'ellipsis-vertical','class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                </summary>
                                <div class="absolute right-0 z-10 mt-1 w-36 rounded-lg bg-white p-1 shadow-lg ring-1 ring-slate-200">
                                    <a href="<?php echo e(route('teacher.lessons.edit', [$selectedSubject->code, $lesson->week])); ?>" class="block rounded-md px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-50">Edit</a>
                                    <a href="<?php echo e(route('teacher.lessons.show', [$selectedSubject->code, $lesson->week])); ?>" class="block rounded-md px-3 py-1.5 text-sm text-slate-700 hover:bg-slate-50">Preview</a>
                                    <form method="POST" action="<?php echo e(route('teacher.lessons.publish', [$selectedSubject->code, $lesson->week])); ?>"><?php echo csrf_field(); ?>
                                        <button type="submit" class="block w-full rounded-md px-3 py-1.5 text-left text-sm text-slate-700 hover:bg-slate-50"><?php echo e($lesson->isPublished() ? 'Move to draft' : 'Publish'); ?></button>
                                    </form>
                                    <form method="POST" action="<?php echo e(route('teacher.lessons.destroy', [$selectedSubject->code, $lesson->week])); ?>" onsubmit="return confirm('Delete Week <?php echo e($lesson->week); ?> and its files?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="block w-full rounded-md px-3 py-1.5 text-left text-sm text-red-600 hover:bg-red-50">Delete</button>
                                    </form>
                                </div>
                            </details>
                        </li>
                        <?php if($loop->last): ?> </ul> <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="rounded-lg border border-dashed border-slate-300 px-6 py-12 text-center text-sm text-slate-500">
                            No lessons yet. Use <strong>Create Lesson</strong> to add the first one.
                        </div>
                    <?php endif; ?>
                </div>

                <div data-panel="analytics" class="mt-4 hidden">
                    <div class="grid gap-3 sm:grid-cols-2">
                        <?php $__currentLoopData = $analytics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-lg bg-slate-50 p-4 ring-1 ring-slate-200">
                                <p class="text-2xl font-bold text-slate-900"><?php echo e($stat['value']); ?></p>
                                <p class="text-sm text-slate-500"><?php echo e($stat['label']); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <p class="mt-3 text-xs text-slate-400">AI chat and reviewer analytics will appear here once those features are built.</p>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            (function () {
                // subject list follows the selected year level
                var year = document.getElementById('year');
                var subject = document.getElementById('subject');
                var options = Array.prototype.slice.call(subject.querySelectorAll('option[data-year]'));

                function filter() {
                    options.forEach(function (o) {
                        var match = !year.value || o.dataset.year === year.value;
                        o.hidden = !match;
                        o.disabled = !match;
                    });
                    if (subject.selectedOptions[0] && subject.selectedOptions[0].disabled) subject.value = '';
                }
                year.addEventListener('change', filter);
                filter();

                // Lessons / Analytics tabs
                var tabs = document.querySelectorAll('[data-tab]');
                var panels = document.querySelectorAll('[data-panel]');
                tabs.forEach(function (t) {
                    t.addEventListener('click', function () {
                        tabs.forEach(function (o) {
                            var on = o === t;
                            o.setAttribute('aria-selected', on ? 'true' : 'false');
                            ['border-blue-700', 'text-blue-700'].forEach(function (c) { o.classList.toggle(c, on); });
                            ['border-transparent', 'text-slate-500', 'hover:text-slate-800'].forEach(function (c) { o.classList.toggle(c, !on); });
                        });
                        panels.forEach(function (p) { p.classList.toggle('hidden', p.dataset.panel !== t.dataset.tab); });
                    });
                });
            })();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $attributes = $__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__attributesOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e)): ?>
<?php $component = $__componentOriginal1ab7467ec53221dd636355c3af7f7d1e; ?>
<?php unset($__componentOriginal1ab7467ec53221dd636355c3af7f7d1e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\AILYN\Downloads\spcc-ai\spcc-ai\resources\views/teacher/subjects.blade.php ENDPATH**/ ?>