<?php if (isset($component)) { $__componentOriginalbc2d976ddc1cb07339bc438da48a7318 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.student','data' => ['title' => 'Profile','active' => 'profile']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Profile','active' => 'profile']); ?>
    <?php ($user = auth()->user()); ?>
    <div class="max-w-2xl rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <div class="flex items-center gap-4">
            <span class="grid size-16 place-items-center rounded-full bg-blue-700 text-xl font-bold text-white">
                <?php echo e(mb_strtoupper(mb_substr($user->name, 0, 1))); ?>

            </span>
            <div>
                <h2 class="text-lg font-bold text-slate-900"><?php echo e($user->name); ?></h2>
                <p class="text-sm text-slate-500">Student</p>
            </div>
        </div>

        <dl class="mt-6 divide-y divide-slate-100 text-sm">
            <div class="flex justify-between gap-4 py-3">
                <dt class="text-slate-500">Full name</dt>
                <dd class="font-medium text-slate-900"><?php echo e($user->name); ?></dd>
            </div>
            <div class="flex justify-between gap-4 py-3">
                <dt class="text-slate-500">SPCC email</dt>
                <dd class="font-medium text-slate-900"><?php echo e($user->email); ?></dd>
            </div>
            <div class="flex justify-between gap-4 py-3">
                <dt class="text-slate-500">Role</dt>
                <dd class="font-medium text-slate-900">Student</dd>
            </div>
        </dl>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $attributes = $__attributesOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__attributesOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318)): ?>
<?php $component = $__componentOriginalbc2d976ddc1cb07339bc438da48a7318; ?>
<?php unset($__componentOriginalbc2d976ddc1cb07339bc438da48a7318); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\spcc-ai\resources\views/student/profile.blade.php ENDPATH**/ ?>