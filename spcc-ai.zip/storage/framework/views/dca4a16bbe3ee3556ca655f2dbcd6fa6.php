<?php if (isset($component)) { $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.auth','data' => ['title' => 'Register']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.auth'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Register']); ?>
    <h1 class="text-center text-lg font-semibold text-slate-900">Register with your SPCC Email</h1>
    <p class="mt-1 text-center text-sm text-slate-500">We will send a 6-digit code to verify your email.</p>

    <form method="POST" action="<?php echo e(route('register.store')); ?>" class="mt-6 space-y-4" novalidate>
        <?php echo csrf_field(); ?>

        <?php if (isset($component)) { $__componentOriginal671d08622d65f2db8ae8bd59009ea50d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.alerts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.alerts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $attributes = $__attributesOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__attributesOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d)): ?>
<?php $component = $__componentOriginal671d08622d65f2db8ae8bd59009ea50d; ?>
<?php unset($__componentOriginal671d08622d65f2db8ae8bd59009ea50d); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.input','data' => ['name' => 'name','label' => 'Full name','icon' => 'user','placeholder' => 'Juan Dela Cruz','autocomplete' => 'name','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'name','label' => 'Full name','icon' => 'user','placeholder' => 'Juan Dela Cruz','autocomplete' => 'name','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $attributes = $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $component = $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.input','data' => ['name' => 'email','type' => 'email','label' => 'SPCC email','icon' => 'envelope','placeholder' => 'Surname_name@spcc.edu.ph','autocomplete' => 'username','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','type' => 'email','label' => 'SPCC email','icon' => 'envelope','placeholder' => 'Surname_name@spcc.edu.ph','autocomplete' => 'username','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $attributes = $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $component = $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>

        <div class="flex items-start gap-3 rounded-lg border border-blue-100 bg-blue-50 px-3.5 py-3">
            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'academic-cap','class' => 'mt-0.5 size-6 shrink-0 text-blue-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'academic-cap','class' => 'mt-0.5 size-6 shrink-0 text-blue-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <div class="text-sm">
                <p class="font-semibold text-blue-900">Only SPCC accounts are allowed</p>
                <p class="mt-0.5 text-blue-800/80">Format: Surname_name@spcc.edu.ph</p>
            </div>
        </div>

        <div>
            <?php if (isset($component)) { $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth.input','data' => ['name' => 'password','type' => 'password','label' => 'Password','icon' => 'lock-closed','placeholder' => 'Create a password','autocomplete' => 'new-password','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'password','type' => 'password','label' => 'Password','icon' => 'lock-closed','placeholder' => 'Create a password','autocomplete' => 'new-password','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $attributes = $__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__attributesOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb)): ?>
<?php $component = $__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb; ?>
<?php unset($__componentOriginal4fe80e9d239d0b60843c2b8ddd36eccb); ?>
<?php endif; ?>
            <p class="mt-1.5 text-xs text-slate-500">At least 8 characters, with letters and numbers.</p>
        </div>

        <button type="submit"
                class="w-full rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2">
            Send OTP
        </button>
    </form>

    <p class="mt-6 text-center text-sm text-slate-600">
        Already have an account?
        <a href="<?php echo e(route('login')); ?>" class="font-semibold text-blue-700 hover:text-blue-800 hover:underline">Sign in</a>
    </p>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $attributes = $__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__attributesOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162)): ?>
<?php $component = $__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162; ?>
<?php unset($__componentOriginal6107cafe1a6b2bb3ae2fbdc60a313162); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/auth/register.blade.php ENDPATH**/ ?>