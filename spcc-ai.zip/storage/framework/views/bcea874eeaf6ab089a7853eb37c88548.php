<?php
    // line chart geometry (inline SVG, no chart library needed)
    $w = 640; $h = 220; $left = 44; $right = 12; $top = 12; $bottom = 28;
    $max = max(4, (int) (ceil(max($usage) / 4) * 4));
    $n = count($usage);
    $pts = [];
    foreach ($usage as $i => $v) {
        $x = $left + ($w - $left - $right) * $i / ($n - 1);
        $y = $top + ($h - $top - $bottom) * (1 - $v / $max);
        $pts[] = round($x, 1).','.round($y, 1);
    }
    $line = implode(' ', $pts);
    $area = $left.','.($h - $bottom).' '.$line.' '.($w - $right).','.($h - $bottom);
    $start = now()->subDays($n - 1);
?>

<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => ['title' => 'Dashboard','active' => 'dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard','active' => 'dashboard']); ?>
    <h2 class="text-lg font-semibold text-slate-900">Dashboard Overview</h2>

    <div class="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <?php $__currentLoopData = [
            ['Total Users', number_format($stats['users']), 'users', 'bg-blue-100 text-blue-700', $stats['growth'] ? '↑ '.$stats['growth'].'% this month' : null],
            ['Students', number_format($stats['students']), 'academic-cap', 'bg-sky-100 text-sky-700', null],
            ['Teachers', number_format($stats['teachers']), 'user', 'bg-orange-100 text-orange-700', null],
            ['Active Lessons', number_format($stats['lessons']), 'book-open', 'bg-green-100 text-green-700', null],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $icon, $tone, $note]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center gap-4 rounded-xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
                <span class="grid size-11 shrink-0 place-items-center rounded-lg <?php echo e($tone); ?>">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => 'size-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </span>
                <div>
                    <p class="text-sm text-slate-500"><?php echo e($label); ?></p>
                    <p class="text-2xl font-bold text-slate-900"><?php echo e($value); ?></p>
                    <?php if($note): ?> <p class="text-xs font-medium text-green-600"><?php echo e($note); ?></p> <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="mt-6 grid gap-6 xl:grid-cols-[1.6fr_1fr]">
        
        <section class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h3 class="font-semibold text-slate-900">System Usage <span class="font-normal text-slate-400">(Last 30 Days)</span></h3>
            <p class="mt-1 flex items-center gap-2 text-xs text-slate-500">
                <span class="inline-block size-2.5 rounded-full bg-blue-600"></span> People who signed in each day
            </p>

            <svg viewBox="0 0 <?php echo e($w); ?> <?php echo e($h); ?>" class="mt-4 w-full" role="img" aria-label="Line chart of daily active users over the last 30 days">
                <?php for($g = 0; $g <= 4; $g++): ?>
                    <?php ($gy = $top + ($h - $top - $bottom) * $g / 4); ?>
                    <line x1="<?php echo e($left); ?>" x2="<?php echo e($w - $right); ?>" y1="<?php echo e($gy); ?>" y2="<?php echo e($gy); ?>" stroke="#e2e8f0" stroke-width="1" />
                    <text x="<?php echo e($left - 8); ?>" y="<?php echo e($gy + 4); ?>" text-anchor="end" font-size="11" fill="#64748b"><?php echo e(number_format($max * (4 - $g) / 4)); ?></text>
                <?php endfor; ?>

                <polygon points="<?php echo e($area); ?>" fill="#2563eb" fill-opacity=".10" />
                <polyline points="<?php echo e($line); ?>" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" />

                <?php $__currentLoopData = $usage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ([$px, $py] = explode(',', $pts[$i])); ?>
                    <circle cx="<?php echo e($px); ?>" cy="<?php echo e($py); ?>" r="<?php echo e($i === $n - 1 ? 4 : 2.5); ?>" fill="#2563eb"><title><?php echo e($start->copy()->addDays($i)->format('M j')); ?>: <?php echo e(number_format($v)); ?> active users</title></circle>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__currentLoopData = [0, 7, 14, 21, 29]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($lx = $left + ($w - $left - $right) * $i / ($n - 1)); ?>
                    <text x="<?php echo e($lx); ?>" y="<?php echo e($h - 8); ?>" text-anchor="middle" font-size="11" fill="#64748b"><?php echo e($start->copy()->addDays($i)->format('M j')); ?></text>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </svg>
        </section>

        
        <section class="rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <h3 class="font-semibold text-slate-900">Recent Activities</h3>
            <?php if($activities->isEmpty()): ?>
                <p class="mt-4 text-sm text-slate-500">Nothing yet. Activity appears here as users and lessons change.</p>
            <?php endif; ?>
            <ul class="mt-4 space-y-4">
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="flex items-start gap-3">
                        <span class="grid size-9 shrink-0 place-items-center rounded-lg <?php echo e($a['tone']); ?>">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $a['icon'],'class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($a['icon']),'class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-medium text-slate-900"><?php echo e($a['title']); ?></p>
                            <p class="truncate text-xs text-slate-500"><?php echo e($a['sub']); ?></p>
                        </div>
                        <p class="shrink-0 text-xs text-slate-400"><?php echo e($a['time']); ?></p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH C:\Users\domain\Downloads\spcc-ai\spcc-ai\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>